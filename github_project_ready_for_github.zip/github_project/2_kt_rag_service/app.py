import os
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError: pass
KB_PATH=Path(__file__).parent/'knowledge_base.md'; CHUNK_SIZE=800; CHUNK_OVERLAP=100; TOP_K=4
STATE={'vector_store':None,'llm':None}
def _get_api_key():
    key=os.getenv('GEMINI_API_KEY')
    if not key: raise ValueError('GEMINI_API_KEY not found. Set it as an environment variable or in .env')
    return key
def _build_index():
    if not KB_PATH.exists(): raise FileNotFoundError(f'Knowledge base file not found: {KB_PATH}')
    text=KB_PATH.read_text(encoding='utf-8')
    chunks=RecursiveCharacterTextSplitter(chunk_size=CHUNK_SIZE,chunk_overlap=CHUNK_OVERLAP).split_text(text)
    docs=[Document(page_content=c,metadata={'chunk_id':i}) for i,c in enumerate(chunks)]
    embeddings=GoogleGenerativeAIEmbeddings(model='gemini-embedding-001',google_api_key=STATE['api_key'])
    return InMemoryVectorStore.from_documents(docs,embeddings)
@asynccontextmanager
async def lifespan(app:FastAPI):
    STATE['api_key']=_get_api_key(); STATE['llm']=ChatGoogleGenerativeAI(model='gemini-3.1-flash-lite',google_api_key=STATE['api_key']); STATE['vector_store']=_build_index(); yield; STATE.clear()
app=FastAPI(title='KT RAG Service',lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
class AskRequest(BaseModel): question:str
@app.get('/')
def root(): return {'status':'ok'}
@app.get('/health')
def health(): return {'status':'ok'}
@app.post('/ask')
def ask(req:AskRequest):
    if not req.question.strip(): raise HTTPException(400,'question cannot be empty')
    vs=STATE.get('vector_store'); llm=STATE.get('llm')
    if vs is None or llm is None: raise HTTPException(503,'RAG index not ready')
    results=vs.similarity_search(req.question,k=TOP_K); context='\n\n---\n\n'.join(d.page_content for d in results)
    prompt=('You are an assistant answering questions using ONLY the context below, which comes from an internal Knowledge Transfer document. If the answer isn\'t in the context, say you don\'t know.\n\nContext:\n'+context+'\n\nQuestion: '+req.question+'\n\nAnswer:')
    response=llm.invoke(prompt); answer=response.content if hasattr(response,'content') else str(response)
    return {'question':req.question,'answer':answer,'sources':[{'chunk_id':d.metadata.get('chunk_id'),'text':d.page_content} for d in results]}
