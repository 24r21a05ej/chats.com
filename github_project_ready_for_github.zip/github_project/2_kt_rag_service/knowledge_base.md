# Knowledge Transfer Document
## Order Management Backend Service — Onboarding & Handover Guide

**Document Owner:** Backend Platform Team  
**Last Updated:** August 2026  
**Audience:** Engineers taking over ownership of the Order Management Service (OMS)

## 1. Service Overview
The Order Management Service (OMS) is the core backend system responsible for handling the full lifecycle of customer orders across the platform — from cart checkout through payment confirmation, fulfillment, and post-order events like returns and refunds.

OMS consists of five cooperating services:
1. **order-api** — public REST API that receives order creation and update requests.
2. **order-processor** — background worker that validates, enriches, and transitions orders.
3. **payment-gateway-adapter** — integration layer for Stripe and webhook normalization.
4. **inventory-sync** — keeps order line items synchronized with Inventory.
5. **notification-dispatcher** — publishes order events to the Notification service.

All five services communicate primarily through Kafka topics with prefix `oms.*`; only order-api is externally exposed through the API gateway.

## 2. Architecture & Data Flow
1. Frontend calls `POST /v2/orders` on order-api.
2. order-api validates the request, writes an order as `PENDING`, and publishes `oms.order.created`.
3. order-processor consumes the event, performs fraud-risk scoring, transitions the order to `AWAITING_PAYMENT`, and emits the next event.
4. payment-gateway-adapter initiates a Stripe payment intent and receives asynchronous Stripe webhooks.
5. Stripe success or failure is published as `oms.payment.succeeded` or `oms.payment.failed`.
6. On success, order-processor transitions the order to `CONFIRMED`, and inventory-sync decrements stock.
7. notification-dispatcher handles the confirmed event and triggers customer notifications.

The primary datastore is PostgreSQL. Each service owns its own schema. Services must not query another service's tables directly; cross-service reads use Kafka events or synchronous REST calls.

## 3. Order State Machine
Orders move through:
`PENDING → AWAITING_PAYMENT → CONFIRMED → FULFILLED → COMPLETED`

Alternative transitions include `PENDING → CANCELLED`, `AWAITING_PAYMENT → CANCELLED`, `CONFIRMED → REFUNDED`, and `FULFILLED → REFUNDED`.

An order can only move to `CANCELLED` from `PENDING` or `AWAITING_PAYMENT`. `REFUNDED` can only be reached from `CONFIRMED` or `FULFILLED`, never from `COMPLETED`.

State transitions are enforced in `order-processor/src/state_machine.py`; do not directly update `orders.status` through production SQL.

## 4. Common Operational Issues
**Stuck orders in AWAITING_PAYMENT:** commonly caused by a missed or delayed Stripe webhook. Check payment-gateway-adapter logs and replay the webhook from Stripe rather than manually editing order state.

**Inventory oversell:** inventory-sync can fall behind because of Kafka consumer lag. A nightly reconciliation job flags negative-stock orders. Check Kafka consumer lag on `oms.order.confirmed`.

**Duplicate order creation:** order-api requires an `Idempotency-Key` header on all `POST /v2/orders` calls. Reusing the same key should return the original order.

**Refund not reflected:** refunds are asynchronous and can take 5–10 business days. Check `refunded_at` before treating it as an incident.

## 5. Deployment & Environments
Services deploy through Jenkins → ArgoCD → Kubernetes. Environments are `dev`, `staging`, and `prod`. Production deployments require two approvals and a canary rollout.

Important variables: `KAFKA_BOOTSTRAP_SERVERS`, `OMS_DB_CONNECTION_STRING`, and `STRIPE_API_KEY` (payment-gateway-adapter only; never hardcode it).

## 6. Monitoring & Alerting
Important Grafana panels: Order creation rate, Kafka consumer lag per topic, Payment webhook latency (p95), and State machine transition errors. Kafka consumer lag is a key early-warning signal.

PagerDuty escalation policy: `oms-oncall`.

## 7. Ownership
- Backend Platform Team — order-api, order-processor, inventory-sync
- Payments Team — payment-gateway-adapter and Stripe integration
- Notifications Team — notification-dispatcher
- Fulfillment Team — inventory reconciliation and shipping issues
- Finance Team — post-completion refund exceptions

## 8. First Week Checklist
1. Get access to OMS Grafana dashboards, PagerDuty, and `#oms-eng`.
2. Trace a complete order lifecycle in staging.
3. Read `order-processor/src/state_machine.py`.
4. Review the last 90 days of OMS incident postmortems.
5. Shadow the current on-call engineer before joining `oms-oncall`.
