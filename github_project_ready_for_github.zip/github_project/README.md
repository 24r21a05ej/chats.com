# FastAPI Gemini LangGraph RAG Project

## 1. Dev/Test Pipeline
`1_dev_test_pipeline/` contains the LangGraph developer/test FastAPI service.

Run:
```bash
cd 1_dev_test_pipeline
pip install -r requirements.txt
uvicorn app:app --reload
```

## 2. KT RAG Service
`2_kt_rag_service/` contains the Gemini embedding + in-memory vector RAG service and `knowledge_base.md`.

Run:
```bash
cd 2_kt_rag_service
pip install -r requirements.txt
uvicorn app:app --reload
```

Set `GEMINI_API_KEY` in a local `.env`. Never commit the real API key.

## 3. Third requirements file
`3_requirements_only/requirements.txt` preserves the additional dependency list provided with the original code.
