import os, sys, io, operator, traceback, uuid
from typing import TypedDict, List, Optional, Annotated, Dict
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_core.tools import tool
from langgraph.graph import StateGraph, START, END
from langchain_google_genai import ChatGoogleGenerativeAI
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

def _get_api_key():
    key=os.getenv('GEMINI_API_KEY')
    if not key: raise ValueError('GEMINI_API_KEY not found. Set it as an environment variable or in .env')
    return key
api_key=_get_api_key()
llm=ChatGoogleGenerativeAI(model='gemini-3.1-flash-lite', google_api_key=api_key)
class CrewState(TypedDict):
    messages: Annotated[List[BaseMessage], operator.add]
    code: Optional[str]
    report: Optional[str]
def _extract_text(content):
    if isinstance(content,list):
        return '\n'.join(item.get('text','') if isinstance(item,dict) else str(item) for item in content)
    return str(content)
@tool
def run_python_code(code:str)->str:
    clean_code=str(code).replace('```python','').replace('```','').strip()
    old_stdout=sys.stdout; new_stdout=io.StringIO(); sys.stdout=new_stdout
    try:
        local_scope={}; exec(clean_code,{},local_scope); result=new_stdout.getvalue()
    except Exception: result=f'Execution Error:\n{traceback.format_exc()}'
    finally: sys.stdout=old_stdout
    return result.strip() if result.strip() else 'Success (no terminal output)'
@tool
def generate_test_cases(task_description:str)->str:
    prompt=f"You are a Senior QA Engineer. Generate 3 to 5 highly specific test scenarios for the following coding task: '{task_description}'. Include standard cases and edge cases. Return them as a numbered list."
    response=llm.invoke(prompt); return _extract_text(response.content)
def real_time_developer(state:CrewState):
    task=_extract_text(state['messages'][-1].content)
    response=llm.invoke(f'Write a clean Python script to solve this: {task}. Only return the code, no explanation or markdown formatting.')
    return {'code':_extract_text(response.content)}
def real_time_tester(state:CrewState):
    task=_extract_text(state['messages'][-1].content)
    cases=generate_test_cases.invoke({'task_description':task})
    execution=run_python_code.invoke({'code':state['code']})
    return {'report':f'### EXECUTION OUTPUT:\n{execution}\n\n### TEST SCENARIOS EVALUATED:\n{cases}'}
workflow=StateGraph(CrewState)
workflow.add_node('developer',real_time_developer); workflow.add_node('tester',real_time_tester)
workflow.add_edge(START,'developer'); workflow.add_edge('developer','tester'); workflow.add_edge('tester',END)
rt_app=workflow.compile()
SESSIONS:Dict[str,dict]={}
app=FastAPI(title='LangGraph Dev/Test Pipeline')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
class TaskRequest(BaseModel): task:str
class DecisionRequest(BaseModel): session_id:str; command:str
@app.get('/')
def root(): return {'status':'ok'}
@app.get('/health')
def health(): return {'status':'ok'}
@app.post('/task')
def submit_task(req:TaskRequest):
    if not req.task.strip(): raise HTTPException(400,'task cannot be empty')
    result=rt_app.invoke({'messages':[HumanMessage(content=req.task)]},config={'recursion_limit':50})
    sid=str(uuid.uuid4()); SESSIONS[sid]={'task':req.task,'code':result.get('code'),'report':result.get('report'),'status':'pending_decision'}
    return {'session_id':sid,'code':result.get('code'),'report':result.get('report')}
@app.post('/decision')
def submit_decision(req:DecisionRequest):
    session=SESSIONS.get(req.session_id)
    if not session: raise HTTPException(404,'session_id not found')
    command=req.command.lower().strip()
    if command not in ('store','another'): raise HTTPException(400,"command must be 'store' or 'another'")
    session['status']='archived' if command=='store' else 'discarded'
    out={'session_id':req.session_id,'status':session['status']}
    if command=='another': out['next']='submit a new task via POST /task'
    return out
@app.get('/session/{session_id}')
def get_session(session_id:str):
    session=SESSIONS.get(session_id)
    if not session: raise HTTPException(404,'session_id not found')
    return session
